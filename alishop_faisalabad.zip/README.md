AliShop Faisalabad — Full Daraz-connected store (Next.js)

What this is
-------------
- A full demo Next.js storefront (AliShop Faisalabad) with Home, Cart, Checkout, Contact.
- Daraz OAuth connect button and server API route stubs.
- Add DARAZ_APP_KEY and DARAZ_APP_SECRET as env vars before deploying.
